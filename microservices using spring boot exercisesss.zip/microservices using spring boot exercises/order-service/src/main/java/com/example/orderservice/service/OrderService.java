package com.example.orderservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.orderservice.entity.Order;
import com.example.orderservice.feign.UserClient;
import com.example.orderservice.model.User;
import com.example.orderservice.repository.OrderRepository;

@Service
public class OrderService {

    @Autowired
    private OrderRepository repository;

    @Autowired
    private UserClient userClient;

    public List<Order> getAllOrders() {
        return repository.findAll();
    }

    public Order saveOrder(Order order) {

        User user = userClient.getUserById(order.getUserId());

        if (user == null) {
            throw new RuntimeException("User Not Found");
        }

        return repository.save(order);
    }

    public Order getOrder(Long id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteOrder(Long id) {
        repository.deleteById(id);
    }
}